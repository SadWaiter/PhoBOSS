package me.earth.phobos.util;

import net.minecraft.client.Minecraft;

public interface Util {
    Minecraft mc = Minecraft.getMinecraft();
}
