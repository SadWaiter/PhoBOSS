package me.earth.phobos.features.modules.render;

import me.earth.phobos.features.modules.Module;

public class BigESP
        extends Module {
    public BigESP() {
        super("BigModule", "Big fucking module", Module.Category.RENDER, true, false, false);
    }
}

