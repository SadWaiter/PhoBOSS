package me.earth.phobos.features.gui.custom;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiNewChat;

public class GuiCustomNewChat
        extends GuiNewChat {
    public GuiCustomNewChat(Minecraft mcIn) {
        super(mcIn);
    }
}

